var ClientCreator = require('./client-creator');

var cc = new ClientCreator();

cc.writeClientServices();
console.log('Finished updating services.');